Models
======

Python-twitter provides the following models of the objects returned by the Twitter API:

* :py:mod:`twitter.category.Category`
* :py:mod:`twitter.direct_message.DirectMessage`
* :py:mod:`twitter.hashtag.Hashtag`
* :py:mod:`twitter.list.List`
* :py:mod:`twitter.media.Media`
* :py:mod:`twitter.status.Status`
* :py:mod:`twitter.trend.Trend`
* :py:mod:`twitter.url.Url`
* :py:mod:`twitter.user.User`
* :py:mod:`twitter.user.UserStatus`

